﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ASP_PROFTAAK.Models;

namespace ASP_PROFTAAK.Controllers
{
    public class ViewModelCreateProduct
    {
        public List<ProductCategorie> categorien = new List<ProductCategorie>();

        public Product product { get; set; }
    }
}