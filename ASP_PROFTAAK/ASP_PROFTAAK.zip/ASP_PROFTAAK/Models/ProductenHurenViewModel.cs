﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASP_PROFTAAK.Models
{
    public class ProductenHurenViewModel
    {
        public ProductExemplaar ProductExemplaar { get; set; }
        public int ResPbId { get; set; }


    }
}